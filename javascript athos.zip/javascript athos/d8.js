var number1 = prompt("esse")
var number2 = prompt("mais esse")
var int = parseInt(number1) + parseInt(number2)
alert("igual a esse " + int)