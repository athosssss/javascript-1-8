var number1 = prompt("escolha um numero a ser feito vezes 2")
var int = parseInt(number1) * 2
alert(" igual a " + int)