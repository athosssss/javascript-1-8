var pri = prompt('media da primeira');
var seg = prompt('mais a da segunda');
var ter = prompt('e a da terceira');
var nota = parseInt(pri)+parseInt(seg)+parseInt(ter);
document.write(nota/3);
