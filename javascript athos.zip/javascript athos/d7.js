var number1 = prompt("qual a altura")
var number2 = prompt("e o comprimento")
var int = parseInt(number1) * parseInt(number2)
alert("A area total dá " + int)