var num1 = prompt('coloque um numero');
var num2 = prompt('vezes');
var multiplication = parseInt(num1) * parseInt(num2);
document.write('a resposta é:'+ multiplication);
