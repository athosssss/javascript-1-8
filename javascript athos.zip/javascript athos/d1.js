var nome = prompt('Diga seu nome');
document.write('Me chamo: ',nome);
