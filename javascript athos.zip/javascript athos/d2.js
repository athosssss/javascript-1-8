var num1 = 10;
var num2 = 18;
total = num1+num2;
alert(total);
